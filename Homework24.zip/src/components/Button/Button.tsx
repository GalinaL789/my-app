import {ButtonComponent} from "./styles";

import { ButtonProps} from "./types";

// Как типизировать props
function Button({ name, isRed = false, type = "button", onClick = () => {} }: ButtonProps) {
  // console.log("i am button");
  // console.log(onClick);
  return (
    <div>
      {/* <p><button onClick={()=>alert()}>Click me</button></p> */}
    <ButtonComponent  name={name} type={type} onClick={onClick}>
      {name}
    </ButtonComponent> </div>
  );
}

export default Button;
