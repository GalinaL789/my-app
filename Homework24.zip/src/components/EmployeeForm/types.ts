export interface EmployeeInfo {
  name: string;
  lastName: string;
  ageValue: string;
  jobPosition: string;
}
