import { useState, useEffect } from "react";

import Input from "components/Input/Input";
import Button from "components/Button/Button";

import { Homework24Wrapper, Joke, ShowError,ShowJoke} from "./styles";
import { error } from "console";

function Homework24() {
  const [joke, setJokes] = useState<string>("");
  const [err, setErr] = useState<string|null>(null);
// Создадим функцию, которая будет вызывать GET запрос для получения шуток
  const getJokes = async () => {
    try {
      const response = await fetch("https://official-joke-api.appspot.com/random_joke");
      const result = await response.json();
      console.log(result);
      if (!response.ok) {
        // Если статус ответа не в пределах 200-299, считаем это ошибкой
        // и гененируем ее таким образом, чтобы отдать result блоку catch
        throw Object.assign(new Error("API Error"), {
          response: result,
        });
      } else {
        setJokes(result.setup);
       setErr(null);
       setTimeout(()=>alert("Приветствую новую шутку"),1000);
      
      }
    } catch (error) {
      setErr("Ошибка при получении данных");
      setTimeout(()=>alert("Ошибка при получении данных"),2000);
    }
  };

  // 1 метод - mounting(первичное отображение DOM элементов)
  // Тут нужно делать действия, которые вы хотите выполнить только вначале
  // Напимер: как только вы открывете страницу с данными пользователя, послать запрос на бэкенд, чтобы эти данные отобразить
  useEffect(() => {
    console.log("Mounting lifecycle method");
    // alert("Mounting lifecycle method")

    getJokes();
  }, []);

  // 2 метод - update(вызывается при перерндеренге компонента)
  // Тут нужно делать действия, которые вы хотите выполнить при перерендеринге(измения state, props, context)
  // Напимер: нам нужно посылать запрос, каждый раз, когда мы вводим букву в клавиатуре
  useEffect(() => {
   console.log("Updating lifecycle method");
   
  },[]);
  //   if (!!joke) {
  //     getJokes();
  //   }
  // }, [inputValue]);

  // 3 метод - unmounting(вызывается, при удалении компонента из DOM)
  // Тут можно например: чистить данные из localstorage или Redux store
  useEffect(() => {
    return () => console.log("Unmointing lifecycle method");
  }, []);
  console.log(!!err);
  return (
    <Homework24Wrapper>
      <Joke>
        <Button name="joke" onClick={getJokes}></Button>
        <ShowJoke>{joke}</ShowJoke>
        <ShowError>{!!err ? err : " "}</ShowError>
      </Joke>
    </Homework24Wrapper>
  );
}

export default Homework24;
