import styled from "@emotion/styled";

export const Homework24Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  padding: 30px;
`;

export const Joke = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 600px;
  min-height: 300px;
  border: 1px solid black;
  border-radius: 10px;
  padding: 30px;
  gap: 40px;
  background-color:lightgreen;
`;

// export const SetJoke= styled.p`
// color: ${(props) => props.err? 'red' : 'black'}; 
// // Если props.error true, то цвет текста красный, иначе черный
//   font-size: 40px;
//   font-weight: bold;
// `;

export const ShowJoke=styled.p`
color: blue;
font-size:30pt;
`;
export const ShowError=styled.p`
color: red;
`;
