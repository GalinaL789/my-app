
// import Homework20 from "./homeworks/Homework20/Homework20";
import GlobalStyles from "styles/GlobalStyles";
import Homework22 from "homeworks/Homework22/Homework22";
import Lesson23 from "lessons/Lesson23/Lesson23";
import Homework23 from "homeworks/Homework23/Homework23";
import Lesson24 from "lessons/Lesson24/Lesson24";
import Homework24 from "homeworks/Homework24/Homework24";
import Lesson25 from "lessons/Lesson25/Lesson25";
import Homework25 from "homeworks/Homework25/Homework25";


function App() {
  return ( 
    <>
      <GlobalStyles/>
      {/* <Lesson20 /> */}
      {/* <Lesson21 /> */}
      {/* <Homework22 /> */}
      {/* <Homework23/> */}
      {/* <Homework24/> */}
      <Homework25/>
      {/* <Homework20 /> */}
      {/* <Homework21 /> */}
      </>
  );
}
export default App;