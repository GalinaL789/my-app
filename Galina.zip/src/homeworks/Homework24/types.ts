export interface JokeInfo {
    answer: string;
    question: string;
}