export interface InputProps {
  id: string;
  name: string;
  placeholder: string;
  label: string;
  type?: string;
  disabled?: boolean;
}
