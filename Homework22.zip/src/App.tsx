
// import Homework20 from "./homeworks/Homework20/Homework20";

import Homework22 from "homeworks/Homework22/Homework22";


function App() {
  return (
    <div className="App">
      {/* <Lesson20 /> */}
      {/* <Lesson21 /> */}
      <Homework22 />
      {/* <Homework20 /> */}
      {/* <Homework21 /> */}
    </div>
  );
}

export default App;