function Lesson20() {
  let someString: string="This is string";
  console.log(someString);
  someString="This is change string";
  console.log(someString);
  // someString=5;
  console.log(someString);
  // let someString2: string=10;
  let somenumber: number=30;
  let numberWithDot: number=110.375;
  let isActive: boolean=true;
  isActive=false;
  // isActive=undefined;
  const animals: string[]=["cat","dog"];
  // animals.push(1000);

    return <div>Lesson 20</div>;
  }
  
  export default Lesson20;