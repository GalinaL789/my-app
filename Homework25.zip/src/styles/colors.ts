interface Colors {
  primary: string;
  secondaryBlue: string;
}

export const colors: Colors = {
  primary: "rgb(26, 35, 53)",
  secondaryBlue: "#1f27f5",
};
