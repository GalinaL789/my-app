export interface CounterProps {
  count: number;
  onMinus: () => void;
  onPlus: () => void;
}

