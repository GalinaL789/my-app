export interface EmployeeInfo {
  name: string;
  lastName: string;
  age: string;
  jobPosition: string;
  agreement: boolean;
  checked:boolean;
}
