import EmployeeForm from "components/EmployeeForm/EmployeeForm";
import { Homework25Wrapper } from "./styles";

function Homework25() {
  return (
    <Homework25Wrapper>
      <EmployeeForm />
    </Homework25Wrapper>
  );
}

export default Homework25;