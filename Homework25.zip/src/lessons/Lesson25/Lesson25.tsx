import LoginForm from "components/LoginForm/LoginForm";

import { Lesson25Wrapper } from "./styles";

function Lesson25() {
  return (
    <Lesson25Wrapper>
      <LoginForm />
    </Lesson25Wrapper>
  );
}

export default Lesson25;